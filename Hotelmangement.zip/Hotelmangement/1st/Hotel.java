class Hotel
{
        private String hotel_name;
        private int regular_weekday;
        private int regular_weekend;
        private int rewardee_weekday;
        private int rewardee_weekend;
        private int rating;
        public void HotelDetails(String hotel_name,int regular_weekday,int regular_weekend,int rewardee_weekday,int rewardee_weekend,int rating)
        {
                this.regular_weekday=regular_weekday;
                this.regular_weekend=regular_weekend;
                this.rewardee_weekday=rewardee_weekday;
                this.rewardee_weekend=rewardee_weekend;
                this.hotel_name=hotel_name;
                this.rating=rating;
       }
        public int getRating()
        {
                return rating;
        }
       public int getRegularWeekDay()
       {
                return regular_weekday;
       }
       public int getRegularWeekEnd()
       {
                return regular_weekend;
       }
       public int  getRewardeeWeekDay()
       {
                return  rewardee_weekday;
       }
       public int getRewardeeWeekEnd()
       {
                return rewardee_weekend;
       }
       public String getHotelName()
       {
                return hotel_name;
       }
}
