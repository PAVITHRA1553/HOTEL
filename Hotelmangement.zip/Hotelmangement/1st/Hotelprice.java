import java.util.*;
class Hotelprice
{
        public static void main(String args[])
        {
            Hotel x= new Hotel(); 
            Hotel y= new Hotel(); 
            Hotel z= new Hotel();
                x.HotelDetails("LakeWood",100,120,90,60,3);                               
                y.HotelDetails("RidgeWood",130,150,100,95,4);            
                z.HotelDetails("BridgeWood",195,150,120,90,5);
              Scanner scan=new Scanner(System.in);
              String s=scan.nextLine();
              int index=s.indexOf(":");
              String type=s.substring(0,index);
              int cost_x=0,cost_y=0,cost_z=0;
              int day_index_start=0,day_index_end=0;
              String day="";
               while(day_index_start!=-1)
              {
                day_index_start=s.indexOf("(",day_index_start+1);
                day_index_end=s.indexOf(")",day_index_end+1);
                if(day_index_start!=-1)
                {
                         day=s.substring(day_index_start+1,day_index_end);
                                if(day.equalsIgnoreCase("sun")||day.equalsIgnoreCase("sat"))
                                {
                                        if(type.equalsIgnoreCase("regular"))
                                        {
                                                
                                                cost_x=cost_x+x.getRegularWeekEnd();
                                                cost_y=cost_y+y.getRegularWeekEnd();
                                                cost_z=cost_z+z.getRegularWeekEnd();
                                        }
                                        else
                                        {
                                                cost_x=cost_x+x.getRewardeeWeekEnd();
                                                cost_y=cost_y+y.getRewardeeWeekEnd();
                                                cost_z=cost_z+z.getRewardeeWeekEnd();
                                        }
                                        
                                }
                                else
                                {
                                        if(type.equalsIgnoreCase("regular"))
                                        {
                                                cost_x=cost_x+x.getRegularWeekDay();
                                                cost_y=cost_y+y.getRegularWeekDay();
                                                cost_z=cost_z+z.getRegularWeekDay();
                                        }
                                        else
                                        {
                                                cost_x=cost_x+x.getRewardeeWeekDay();
                                                cost_y=cost_y+y.getRewardeeWeekDay();
                                                cost_z=cost_z+z.getRewardeeWeekDay();
                                        }
                                
                                }
                     }
              }
              System.out.println(cost_x+" "+cost_y+" "+cost_z);
              Minimumprice minimumprice=new Minimumprice();
              String result=minimumprice.min(cost_x,cost_y,cost_z,x,y,z);
              System.out.println("HotelName:"+result);
              
              
             
        }
  }
