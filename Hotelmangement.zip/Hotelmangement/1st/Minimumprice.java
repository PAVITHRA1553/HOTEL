class Minimumprice
{
        public static String min(int a,int b,int c,Hotel x,Hotel y,Hotel z)
        {
                if(a<b && a<c)
                {
                        return x.getHotelName();
                }
                else if(b<a && b<c)
                {
                       return y.getHotelName();
                }
                else if(c<a && c<b)
                {
                       return z.getHotelName();
                }
                else if(a==b)
                {
                        if(x.getRating()>y.getRating())
                        {
                                return x.getHotelName();
                        }
                        else
                        {
                                return y.getHotelName();
                        }
                }
                else if(c==a)
                {
                      if(z.getRating()>x.getRating())
                        {
                                return z.getHotelName();
                        }
                        else
                        {
                                return x.getHotelName();
                        }  
                }
                else if(b==c)
                {
                       if(y.getRating()>z.getRating())
                        {
                                return y.getHotelName();
                        }
                        else
                        {
                                return z.getHotelName();
                        } 
                }
                else
                {
                        return x.getHotelName();
                }                
        }
            
}
