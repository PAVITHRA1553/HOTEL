import java.util.*;
class LakeWoodhotel extends Hotel
{
           
        public String getHotelName()
        {
                hotel_name="LakeWood";
                return hotel_name;
        }
        public int getRegularWeekdayCost()
        {
                regular_weekdaycost=100;
                return regular_weekdaycost;
        }
        public int getRegularWeekendCost()
        {
                regular_weekendcost=120;
                return regular_weekendcost;
        }
        public int getRewardeeWeekdaycost()
        {
                rewardee_weekdaycost=90;
                return rewardee_weekdaycost;
        }
        public int getRewardeeWeekendcost()
        {
                rewardee_weekendcost=60;
                return rewardee_weekendcost;
        }
              

}
