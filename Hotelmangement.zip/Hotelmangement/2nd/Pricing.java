import java.util.*;
class Pricing
{
        public static void main(String[] args)
        {
                Hotel_factroy hotel=new Hotel_factroy();
                Scanner scan=new Scanner(System.in);
                String input=scan.nextLine();
                int customertype_index=input.indexOf(":");
                String customertype=input.substring(0,customertype_index);
                int cost_Lakewood=0,cost_Ridgewood=0,cost_bridgewood=0;
                int day_index_start=0,day_index_end=0;
                String day="";
                 Hotel lakewood=hotel.gethotel("LakeWood");
                 Hotel ridgewood=hotel.gethotel("RidgeWood");
                 Hotel bridgewood=hotel.gethotel("BridgeWood");
                 System.out.println(lakewood.getRegularWeekendCost());
                while(day_index_start!=-1)
                {
                        day_index_start=input.indexOf("(",day_index_start+1);
                        day_index_end=input.indexOf(")",day_index_end+1);
                 if(day_index_start!=-1)
                 {
                        day=input.substring(day_index_start+1,day_index_end);
                        
                        if(day.equalsIgnoreCase("sun")||day.equalsIgnoreCase("sat"))
                        {
                               if(customertype.equalsIgnoreCase("regular"))
                               {
                                          cost_Lakewood=cost_Lakewood+lakewood.getRegularWeekendCost();
                                          cost_Ridgewood=cost_Ridgewood+ridgewood.getRegularWeekendCost();
                                          cost_bridgewood=cost_bridgewood+bridgewood.getRegularWeekendCost();
                               }
                               else
                               {
                                        cost_Lakewood=cost_Lakewood+lakewood.getRewardeeWeekendcost();
                                        cost_Ridgewood=cost_Ridgewood+ridgewood.getRewardeeWeekendcost();
                                        cost_bridgewood=cost_bridgewood+bridgewood.getRewardeeWeekendcost();
                               }       
                        }
                        else
                        {
                                if(customertype.equalsIgnoreCase("regular"))
                               {
                                        cost_Lakewood=cost_Lakewood+lakewood.getRegularWeekdayCost();
                                        cost_Ridgewood=cost_Ridgewood+ridgewood.getRegularWeekdayCost();
                                        cost_bridgewood=cost_bridgewood+bridgewood.getRegularWeekdayCost();
                               }
                               else
                               {
                                        cost_Lakewood=cost_Lakewood+lakewood.getRewardeeWeekdaycost();
                                        cost_Ridgewood=cost_Ridgewood+ridgewood.getRewardeeWeekdaycost();
                                        cost_bridgewood=cost_bridgewood+bridgewood.getRewardeeWeekdaycost();
                               }
                        }
                   }
                   else
                   {
                        break;
                   }
                }
              System.out.println(cost_Lakewood+" "+cost_Ridgewood+" "+cost_bridgewood);
              String result=min(cost_Lakewood,cost_Ridgewood,cost_bridgewood);
              System.out.println("HotelName:"+result);
        }
         private static String min(int a,int b,int c)
        {
                if(a<b && a<c)
                {
                        return "LakeWood";
                }
                else if(b<a && b<c)
                {
                        return  "RidgeWood";
                }
                else if(c<a && c<b)
                {
                        return "BridgeWood";
                }
                else if(a==b || b==c)
                {
                        return "RidgeWood";
                }
                else if(c==a)
                {
                      return "BridgeWood";  
                }
                else
                {
                        return "LakeWood";
                }                
        }
}
