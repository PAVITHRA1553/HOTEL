import java.util.*;
abstract class Hotel
{
        public String hotel_name;
        public int regular_weekdaycost;
        public int regular_weekendcost;
        public int rewardee_weekdaycost;
        public int rewardee_weekendcost;
        abstract String getHotelName();
        abstract int getRegularWeekdayCost();
        abstract int getRegularWeekendCost();
        abstract int getRewardeeWeekdaycost();
        abstract int getRewardeeWeekendcost();
}
