import java.util.*;
class Hotel_factroy
{
        public Hotel gethotel(String hotelname)
        {
                if(hotelname==null)
                {
                        return null;
                }
                else if(hotelname.equalsIgnoreCase("LakeWood"))
                {
                        LakeWoodhotel lak=new LakeWoodhotel();
                        return lak;
                } 
                else if(hotelname.equalsIgnoreCase("RidgeWood"))
                {
                        RidgeWoodhotel rh=new RidgeWoodhotel();
                        return rh;
                } 
                else if(hotelname.equalsIgnoreCase("BridgeWood"))
                {
                        BridgeWoodhotel bh= new BridgeWoodhotel();
                        return bh;
                } 
                return null;  
        }
}    
