import java.util.*;
class RidgeWoodhotel extends Hotel
{
            
        public String getHotelName()
        {
                hotel_name="RidgeWood";
                return hotel_name;
        }
        public int getRegularWeekdayCost()
        {
                regular_weekdaycost=130;
                return regular_weekdaycost;
        }
        public int getRegularWeekendCost()
        {
                regular_weekendcost=150;
                return regular_weekendcost;
        }
        public int getRewardeeWeekdaycost()
        {
                rewardee_weekdaycost=100;
                return rewardee_weekdaycost;
        }
        public int getRewardeeWeekendcost()
        {
                rewardee_weekendcost=95;
                return rewardee_weekendcost;
        }
              

}
